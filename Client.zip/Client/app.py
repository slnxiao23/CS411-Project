from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///finance.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    transaction_type = db.Column(db.String(50), nullable=False)

# get transaction
@app.route('/get-transactions')
def get_transactions():
    transactions = Transaction.query.all()
    transactions_data = [{
        'id': tx.id,
        'description': tx.description,
        'amount': tx.amount,
        'type': tx.transaction_type
    } for tx in transactions]
    return jsonify({'transactions': transactions_data})

    # Add the transaction
@app.route('/add-transaction', methods=['POST'])
def add_transaction():
    data = request.get_json()
    new_transaction = Transaction(
        description=data['description'],
        amount=data['amount'],
        transaction_type=data['type']
    )
    db.session.add(new_transaction)
    db.session.commit()
    return jsonify({'status': 'success', 'message': 'Transaction added'})


    # Delete the transaction
@app.route('/delete-transaction/<int:id>', methods=['POST'])
def delete_transaction(id):
    transaction = Transaction.query.get(id)
    if transaction:
        db.session.delete(transaction)
        db.session.commit()
        return jsonify({'status': 'success', 'message': 'Transaction deleted'})
    else:
        return jsonify({'status': 'error', 'message': 'Transaction not found'}), 404

@app.route('/')
def home():
    transactions = Transaction.query.all()
    return render_template('index.html', transactions=transactions)


if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Ensure tables are created before running the app
    app.run(debug=True, port=5002)

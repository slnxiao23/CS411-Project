const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const app = express();
app.use(express.json());

app.post('/transaction', (req, res) => {
    let db = new sqlite3.Database('./finance.db', sqlite3.OPEN_READWRITE, (err) => {
        if (err) {
            console.error(err.message);
            res.status(500).send({ status: 'error', message: 'Failed to connect to the database' });
            return;
        }
        console.log('Connected to the finance database.');
    });

    db.run(`INSERT INTO finances(type, amount, currency) VALUES(?, ?, ?)`, [req.body.type, req.body.amount, req.body.currency], function(err) {
        if (err) {
            console.error(err.message);
            res.status(500).send({ status: 'error', message: 'Failed to insert transaction' });
            return;
        }
        console.log(`A row has been inserted with rowid ${this.lastID}`);
        res.send({ status: 'success', transactionId: this.lastID });
    });

    db.close((err) => {
        if (err) {
            console.error(err.message);
        }
        console.log('Close the database connection.');
    });
});


app.listen(3000, () => {
    console.log('Server is running on port 3000');

    // Create a new database and table if they don't exist
    let db = new sqlite3.Database('./finance.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
        if (err) {
            console.error(err.message);
        }
        console.log('Connected to the finance database.');
    });

    db.run(`CREATE TABLE IF NOT EXISTS finances (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        currency TEXT NOT NULL
    )`);

    db.close((err) => {
        if (err) {
            console.error(err.message);
        }
        console.log('Close the database connection.');
    });
});

import { fetchSelectedCurrencyRate} from '/static/exchangeRate.js';


document.addEventListener('DOMContentLoaded', function () {

    //Call exchang erate file
    const rateButton = document.getElementById('rate-check-button');
    rateButton.addEventListener('click', fetchSelectedCurrencyRate);
    // Define initial arrays to store income and expense data
    const incomeData = [];
    const expenseData = [];
    let transactions = [];



    // Function to calculate total income and expenses
    function calculateTotal(data) {
        return data.reduce((acc, val) => acc + val, 0);
    }

    // Create pie chart for financial overview
    const ctx = document.getElementById('financial-chart').getContext('2d');
    const financialChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Income', 'Expenses'],
            datasets: [
                {
                    label: 'Financial Overview',
                    data: [calculateTotal(incomeData), calculateTotal(expenseData)],
                    backgroundColor: ['green', 'red'],
                },
            ],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
                position: 'right',
            },
        },
    });

    // Function to update the financial summary and chart based on transactions
    function updateFinancialData() {
        const totalIncome = transactions.reduce((acc, transaction) => transaction.type === 'income' ? acc + transaction.amount : acc, 0);
        const totalExpenses = transactions.reduce((acc, transaction) => transaction.type === 'expense' ? acc + transaction.amount : acc, 0);
        const netSavings = totalIncome - totalExpenses;

        document.getElementById('total-income').textContent = totalIncome.toFixed(2);
        document.getElementById('total-expenses').textContent = totalExpenses.toFixed(2);
        document.getElementById('net-savings').textContent = netSavings.toFixed(2);

        financialChart.data.datasets[0].data = [totalIncome, totalExpenses];
        financialChart.update();
    }

    // Event listener for form submission to add new transaction
    // Event listener for form submission to add new transaction
    document.getElementById('transaction-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const description = this.querySelector('input[name="description"]').value;
        const amount = parseFloat(this.querySelector('input[name="amount"]').value.replace(/\$|,/g, ''));
        const type = this.querySelector('select[name="type"]').value;

        const newTransaction = {
            description: description,
            amount: amount,
            type: type
        };
        transactions.push(newTransaction);
        updateFinancialData();
        addTransactionToList(newTransaction);
        this.reset();

        // Send the new transaction data to the server
        fetch('http://127.0.0.1:3000/transaction', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newTransaction),
        })
        .then(response => {
            if (response.ok) {
                return response.json(); // Process response if it's JSON.
            }
            throw new Error('Network response was not ok.'); // Handle non-OK responses.
        })
        .then(data => {
            console.log('Transaction saved:', data);
            alert('Transaction successfully saved!'); // Provide user feedback on success.
        })
        .catch((error) => {
            console.error('Error:', error);
            alert('Failed to save transaction.'); // Provide user feedback on failure.
        });
    });



    // Function to add transaction to the HTML list
    function addTransactionToList(transaction) {
        const list = document.getElementById('transactions-list').querySelector('ul');
        const item = document.createElement('li');
        item.textContent = `${transaction.description} - $${transaction.amount.toFixed(2)} (${transaction.type})`;
        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.onclick = function () { removeTransaction(transaction.id); };
        item.appendChild(removeButton);
        list.appendChild(item);
    }

    // Function to remove a transaction by ID
    function removeTransaction(transactionId) {
        transactions = transactions.filter(transaction => transaction.id !== transactionId);
        updateFinancialData();
        document.getElementById('transactions-list').querySelector('ul').innerHTML = '';
        transactions.forEach(addTransactionToList);
    }

    // Utility function to generate a unique ID for each transaction
    function generateUniqueId() {
        return Math.random().toString(36).substr(2, 9);
    }

    


});

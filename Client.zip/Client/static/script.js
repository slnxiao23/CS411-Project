import { fetchSelectedCurrencyRate } from '/static/exchangeRate.js';

document.addEventListener('DOMContentLoaded', function () {
    let transactions = [];
    const incomeData = [];
    const expenseData = [];

    // Fetch existing transactions and initialize the application
    fetch('/get-transactions')
    .then(response => response.json())
    .then(data => {
        transactions = data.transactions;
        transactions.forEach(transaction => addTransactionToList(transaction));
        updateFinancialData();
    })
    .catch(error => console.error('Failed to load transactions:', error));

    // Event listener for currency rate checking
    const rateButton = document.getElementById('rate-check-button');
    rateButton.addEventListener('click', fetchSelectedCurrencyRate);

    // Initialize pie chart for financial overview
    const ctx = document.getElementById('financial-chart').getContext('2d');
    const financialChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Income', 'Expenses'],
            datasets: [{
                label: 'Financial Overview',
                data: [calculateTotal(incomeData), calculateTotal(expenseData)],
                backgroundColor: ['green', 'red'],
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: { position: 'right' },
        },
    });

    // Handle form submission for new transactions
    document.getElementById('transaction-form').addEventListener('submit', function (e) {
        e.preventDefault();
        const description = this.querySelector('input[name="description"]').value;
        const amount = parseFloat(this.querySelector('input[name="amount"]').value.replace(/\$|,/g, ''));
        const type = this.querySelector('select[name="type"]').value;

        const newTransaction = { description, amount, type };

        fetch('/add-transaction', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newTransaction),
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                location.reload();  // Reload to update the list from server
            } else {
                alert('Failed to save transaction.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to save transaction.');
        });
    });

    // Function to add a transaction to the list
    function addTransactionToList(transaction) {
        const list = document.getElementById('transactions-list');
        const item = document.createElement('li');
        item.textContent = `${transaction.description} - $${transaction.amount.toFixed(2)} (${transaction.type})`;

        const removeButton = document.createElement('button');
        removeButton.textContent = 'Remove';
        removeButton.setAttribute('data-id', transaction.id);
        item.appendChild(removeButton);
        list.appendChild(item);
    }

    // Event delegation for remove buttons
    document.getElementById('transactions-list').addEventListener('click', function(event) {
        if (event.target.tagName === 'BUTTON' && event.target.textContent === 'Remove') {
            removeTransaction(event.target);
        }
    });

    // Remove transaction function
    function removeTransaction(buttonElement) {
        const transactionId = buttonElement.getAttribute('data-id');
        if (!transactionId) {
            console.error('Transaction ID is null or undefined');
            return; // Stop further execution
        }
    
        fetch(`/delete-transaction/${transactionId}`, {
            method: 'POST',
        })
        .then(response => {
            if (!response.ok) throw new Error('Failed to delete transaction');
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                // Remove the transaction element from the DOM
                buttonElement.closest('li').remove();
                alert('Transaction removed successfully!');
            } else {
                alert('Failed to remove transaction.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error removing transaction.');
        });
    }
    

    // Calculate totals for the financial chart
    function calculateTotal(data) {
        return data.reduce((acc, val) => acc + val, 0);
    }

    // Update financial data and refresh the chart
    function updateFinancialData() {
        const totalIncome = transactions.reduce((acc, transaction) => transaction.type === 'income' ? acc + transaction.amount : acc, 0);
        const totalExpenses = transactions.reduce((acc, transaction) => transaction.type === 'expense' ? acc + transaction.amount : acc, 0);
        const netSavings = totalIncome - totalExpenses;

        document.getElementById('total-income').textContent = totalIncome.toFixed(2);
        document.getElementById('total-expenses').textContent = totalExpenses.toFixed(2);
        document.getElementById('net-savings').textContent = netSavings.toFixed(2);

        financialChart.data.datasets[0].data = [totalIncome, totalExpenses];
        financialChart.update();
    }
});
